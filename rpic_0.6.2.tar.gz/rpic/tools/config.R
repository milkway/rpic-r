# Note: Any variables prefixed with `.` are used for text
# replacement in the Makevars.in and Makevars.win.in

# check the packages MSRV first
source("tools/msrv.R")

# check DEBUG and NOT_CRAN environment variables
env_debug <- Sys.getenv("DEBUG")
env_not_cran <- Sys.getenv("NOT_CRAN")

# check if the vendored zip file exists
vendor_exists <- file.exists("src/rust/vendor.tar.xz")

is_not_cran <- env_not_cran != ""
is_debug <- env_debug != ""

if (is_debug) {
  # if we have DEBUG then we set not cran to true
  # CRAN is always release build
  is_not_cran <- TRUE
  message("Creating DEBUG build.")
}

if (!is_not_cran) {
  message("Building for CRAN.")
  # CRAN builds MUST be offline from vendored sources (CRAN Rust policy).
  # A tarball built without running rextendr::vendor_crates(".") first
  # silently downloaded crates on the 0.6.2 pretest (Debian WARNING) and
  # built online/unbounded on Windows. Fail closed instead:
  if (!vendor_exists) {
    stop(
      "src/rust/vendor.tar.xz is missing.\n",
      "  - Submitting/building for CRAN: run rextendr::vendor_crates(\".\") first.\n",
      "  - Local dev build from a git clone: set NOT_CRAN=true.",
      call. = FALSE
    )
  }
}

# we set cran flags only if NOT_CRAN is empty and if
# the vendored crates are present.
# CRAN policy: at most 2 build jobs; offline whenever the vendored
# sources are present (for CRAN they always are — see the guard above).
.cran_flags <- if (!is_not_cran) {
  "-j 2 --offline"
} else if (vendor_exists) {
  "--offline"
} else {
  ""
}

# when DEBUG env var is present we use `--debug` build
.profile <- ifelse(is_debug, "", "--release")
.clean_targets <- ifelse(is_debug, "", "$(TARGET_DIR)")

# We specify this target when building for webR
webr_target <- "wasm32-unknown-emscripten"

# here we check if the platform we are building for is webr
is_wasm <- identical(R.version$platform, webr_target)

# print to terminal to inform we are building for webr
if (is_wasm) {
  message("Building for WebR")
}

# we check if we are making a debug build or not
# if so, the LIBDIR environment variable becomes:
# LIBDIR = $(TARGET_DIR)/{wasm32-unknown-emscripten}/debug
# this will be used to fill out the LIBDIR env var for Makevars.in
target_libpath <- if (is_wasm) "wasm32-unknown-emscripten" else NULL
cfg <- if (is_debug) "debug" else "release"

# used to replace @LIBDIR@
.libdir <- paste(c(target_libpath, cfg), collapse = "/")

# use this to replace @TARGET@
# we specify the target _only_ on webR
# there may be use cases later where this can be adapted or expanded
.target <- ifelse(is_wasm, paste0("--target=", webr_target), "")

# add panic exports only for WASM builds
.panic_exports <- ifelse(
  is_wasm,
  "CARGO_PROFILE_DEV_PANIC=\"abort\" CARGO_PROFILE_RELEASE_PANIC=\"abort\" ",
  ""
)

# read in the Makevars.in file checking
is_windows <- .Platform[["OS.type"]] == "windows"

# if windows we replace in the Makevars.win.in
mv_fp <- ifelse(
  is_windows,
  "src/Makevars.win.in",
  "src/Makevars.in"
)

# set the output file
mv_ofp <- ifelse(
  is_windows,
  "src/Makevars.win",
  "src/Makevars"
)

# delete the existing Makevars{.win/.wasm}
if (file.exists(mv_ofp)) {
  message("Cleaning previous `", mv_ofp, "`.")
  invisible(file.remove(mv_ofp))
}

# CRAN builds must use the pre-generated R/extendr-wrappers.R shipped in
# the tarball instead of regenerating it at install time: the `document`
# bin recompiles proc-macro2/quote in the debug profile, and their build
# scripts hit a spurious "os error 193" on CRAN's Windows builder (seen on
# the 0.6.2 pretest and reproduced on win-builder even with the offline
# vendored build). Developers still regenerate wrappers on NOT_CRAN builds.
.document_run <- if (is_not_cran) {
  if (is_windows) {
    "cargo run @CRAN_FLAGS@ --bin document --target $(TARGET) --manifest-path=./rust/Cargo.toml --target-dir $(TARGET_DIR)"
  } else {
    "cargo run @CRAN_FLAGS@ --bin document --manifest-path=./rust/Cargo.toml --target-dir $(TARGET_DIR) @TARGET@"
  }
} else {
  "echo 'Building for CRAN: using the pre-generated extendr wrappers.'"
}

# read as a single string
mv_txt <- readLines(mv_fp)

# replace placeholder values
new_txt <- gsub("@DOCUMENT_RUN@", .document_run, mv_txt) |>
  gsub("@CRAN_FLAGS@", .cran_flags, x = _) |>
  gsub("@PROFILE@", .profile, x = _) |>
  gsub("@CLEAN_TARGET@", .clean_targets, x = _) |>
  gsub("@LIBDIR@", .libdir, x = _) |>
  gsub("@TARGET@", .target, x = _) |>
  gsub("@PANIC_EXPORTS@", .panic_exports, x = _)

message("Writing `", mv_ofp, "`.")
con <- file(mv_ofp, open = "wb")
writeLines(new_txt, con, sep = "\n")
close(con)

message("`tools/config.R` has finished.")
